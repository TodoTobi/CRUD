
package clientes;

import java.sql.DriverManager;
import java.sql.Connection;
import javax.swing.JOptionPane;

public class CConexion {
   
    
    Connection conectar = null;
    String usuario = "root";
    String contrasenia = "";
    String bd = "gestion_empresa";
    String ip = "localhost";
    String puerto = "3306";
    
    String cadena = "jdbc:mysql://" + ip + ": " + puerto + "/" + bd;
    
    public Connection estableceConexion(){
        
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena,usuario,contrasenia);
            JOptionPane.showMessageDialog(null,"La conexion se realizo");
            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error al conectar" + e.toString());
        }
        return conectar;
    }
    
}
