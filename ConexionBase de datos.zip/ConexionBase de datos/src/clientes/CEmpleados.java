
package clientes;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.CallableStatement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;

/**
 *
 * @author CFP36-ADMIN
 */
public class CEmpleados {
    
    int codigo;
    String nombreEmpleado;
    String apellidosEmpleado;
    String dni;
    String legajo;
    String salario;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getApellidosEmpleado() {
        return apellidosEmpleado;
    }

    public void setApellidosEmpleado(String apellidosEmpleado) {
        this.apellidosEmpleado = apellidosEmpleado;
    }
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getLegajo() {
        return legajo;
    }

    public void setLegajo(String legajo) {
        this.legajo = legajo;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }


    public void InsertarCliente(JTextField paramNombre, JTextField paramApellido, JTextField paramDni, JTextField paramLegajo, JTextField paramSalario){

    setNombreEmpleado(paramNombre.getText());
    setApellidosEmpleado(paramApellido.getText());
    setDni(paramDni.getText());
    setLegajo(paramLegajo.getText());
    setSalario(paramSalario.getText());

    CConexion objetoConexion = new CConexion();

    String consulta = "INSERT INTO empleado (nombre, apellido, dni, legajo, salario) VALUES (?, ?, ?, ?, ?)";

    try {

        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);

        cs.setString(1, getNombreEmpleado());
        cs.setString(2, getApellidosEmpleado());
        cs.setString(3, getDni());
        cs.setString(4, getLegajo());
        cs.setString(5, getSalario());

        cs.execute();

        JOptionPane.showMessageDialog(null, "Inserción de empleado exitosa");
    } catch (SQLException e) {

        JOptionPane.showMessageDialog(null, "Error al insertar empleado: " + e.toString());
    }
}

    public void MostrarClientes(JTable paramTablaTotalEmpleados){
    CConexion objetoConexion = new CConexion();

    DefaultTableModel modelo = new DefaultTableModel();
    TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<>(modelo);
    paramTablaTotalEmpleados.setRowSorter(OrdenarTabla);

    String sql = "SELECT * FROM empleado;";
    
    modelo.addColumn("id");
    modelo.addColumn("nombre");
    modelo.addColumn("apellido");
    modelo.addColumn("dni");
    modelo.addColumn("legajo");
    modelo.addColumn("salario");

    paramTablaTotalEmpleados.setModel(modelo);

    String[] datos = new String[6];
    Statement st;

    try {
        st = objetoConexion.estableceConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            datos[0] = rs.getString(1);
            datos[1] = rs.getString(2);
            datos[2] = rs.getString(3);
            datos[3] = rs.getString(4);
            datos[4] = rs.getString(5);
            datos[5] = rs.getString(6);

            modelo.addRow(datos);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al mostrar empleados: " + e.toString());
    }
}

      public void SeleccionarCliente(JTable paramTablaTotalEmpleados, JTextField paramid, JTextField paramnombres, JTextField paramapellidos, JTextField paramdireccion){
          try {
              int fila = paramTablaTotalEmpleados.getSelectedRow();
              
              if (fila >= 0){
                  paramid.setText(paramTablaTotalEmpleados.getValueAt(fila,0).toString());
                  paramnombres.setText(paramTablaTotalEmpleados.getValueAt(fila,1).toString());
                  paramapellidos.setText(paramTablaTotalEmpleados.getValueAt(fila,2).toString());
                  paramdireccion.setText(paramTablaTotalEmpleados.getValueAt(fila,3).toString());
              }else{
                  JOptionPane.showMessageDialog(null,"Fila no seleccionada");
              }
          } catch (Exception e) {
              JOptionPane.showMessageDialog(null,"Error de seleccion, error: " + e.toString());
          }
      }
    public void ModificarEmpleado(JTextField paramIdEmpleado, JTextField paramNombreEmpleado, JTextField paramApellidoEmpleado, JTextField paramDni, JTextField paramLegajo, JTextField paramSalario) {

    setCodigo(Integer.parseInt(paramIdEmpleado.getText()));
    setNombreEmpleado(paramNombreEmpleado.getText());
    setApellidosEmpleado(paramApellidoEmpleado.getText());
    setDni(paramDni.getText());
    setLegajo(paramLegajo.getText());
    setSalario(paramSalario.getText());

    CConexion objetoConexion = new CConexion();

    String consulta = "UPDATE empleado SET nombre = ?, apellido = ?, dni = ?, legajo = ?, salario = ? WHERE id = ?";

    try {

        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);

        
        cs.setString(1, getNombreEmpleado());
        cs.setString(2, getApellidosEmpleado());
        cs.setString(3, getDni());
        cs.setString(4, getLegajo());
        cs.setString(5, getSalario());
        cs.setInt(6, getCodigo());

        cs.execute();

        JOptionPane.showMessageDialog(null, "Modificación de empleado exitosa");
    } catch (SQLException e) {

        JOptionPane.showMessageDialog(null, "Error al modificar empleado: " + e.toString());
    }
}
    public void EliminarClientes(JTextField paramCodigo){
        setCodigo(Integer.parseInt(paramCodigo.getText()));
        
        CConexion objetoCOnexion = new CConexion();
        
        String consulta = "DELETE FROM empleado WHERE empleado.id = ?; ";
        
        try {
            CallableStatement cs = objetoCOnexion.estableceConexion().prepareCall(consulta);
            cs.setInt(1, getCodigo());
            cs.execute();
            JOptionPane.showMessageDialog(null, "Eliminacion exitosa ");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Eliminacion Fallida: " + e.toString());
        }
    }
}
