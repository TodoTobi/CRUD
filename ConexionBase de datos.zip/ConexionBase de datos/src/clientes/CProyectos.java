
package clientes;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.CallableStatement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;

/**
 *
 * @author CFP36-ADMIN
 */
public class CProyectos {
    
    int codigo;
    String nombre;
    String descripcion;
    String presupuesto;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombreClientes) {
        this.nombre = nombreClientes;
    }
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(String presupuesto) {
        this.presupuesto = presupuesto;
    }

   public void InsertarProyecto(JTextField paramNombre, JTextField paramDescripcion, JTextField paramPresupuesto){
    setNombre(paramNombre.getText());
    setDescripcion(paramDescripcion.getText());
    setPresupuesto(paramPresupuesto.getText());

    CConexion objetoConexion = new CConexion();

    String consulta = "INSERT INTO proyecto (nombre, descripcion, presupuesto) values (?, ?, ?)";

    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);

        cs.setString(1, getNombre());
        cs.setString(2, getDescripcion());
        cs.setString(3, getPresupuesto());

        cs.execute();
        JOptionPane.showMessageDialog(null, "Inserción de proyecto exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar proyecto: " + e.toString());
    }
}

    public void MostrarProyecto(JTable paramTablaTotalProyectos){
    CConexion objetoConexion = new CConexion();

    DefaultTableModel modelo = new DefaultTableModel();
    TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<>(modelo);
    paramTablaTotalProyectos.setRowSorter(OrdenarTabla);

    String sql = "SELECT * FROM proyecto;";
    
    modelo.addColumn("id");
    modelo.addColumn("nombre");
    modelo.addColumn("descripcion");
    modelo.addColumn("presupuesto");

    paramTablaTotalProyectos.setModel(modelo);

    String[] datos = new String[4];
    Statement st;

    try {
        st = objetoConexion.estableceConexion().createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            datos[0] = rs.getString(1);
            datos[1] = rs.getString(2);
            datos[2] = rs.getString(3);
            datos[3] = rs.getString(4);

            modelo.addRow(datos);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al mostrar proyectos: " + e.toString());
    }
}

      public void SeleccionarProyecto(JTable paramTablaTotalProyectos, JTextField paramid, JTextField paramNombre, JTextField paramDescripcion, JTextField paramPresupuesto){
          try {
              int fila = paramTablaTotalProyectos.getSelectedRow();
              
              if (fila >= 0){
                  paramid.setText(paramTablaTotalProyectos.getValueAt(fila,0).toString());
                  paramNombre.setText(paramTablaTotalProyectos.getValueAt(fila,1).toString());
                  paramDescripcion.setText(paramTablaTotalProyectos.getValueAt(fila,2).toString());
                  paramPresupuesto.setText(paramTablaTotalProyectos.getValueAt(fila,2).toString());
              }else{
                  JOptionPane.showMessageDialog(null,"Fila no seleccionada");
              }
          } catch (Exception e) {
              JOptionPane.showMessageDialog(null,"Error de seleccion, error: " + e.toString());
          }
      }
    
    public void ModificarProyecto(JTextField paramId, JTextField paramNombre, JTextField paramDescripcion, JTextField paramPresupuesto) {

    setCodigo(Integer.parseInt(paramId.getText()));
    setNombre(paramNombre.getText());
    setDescripcion(paramDescripcion.getText());
    setPresupuesto(paramPresupuesto.getText());

    CConexion objetoConexion = new CConexion();

    String consulta = "UPDATE proyecto SET nombre = ?, descripcion = ?, presupuesto = ? WHERE id = ?";

    try {

        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);

        cs.setString(1, getNombre());
        cs.setString(2, getDescripcion());
        cs.setString(3, getPresupuesto());
        cs.setInt(4, getCodigo());

        cs.execute();

        JOptionPane.showMessageDialog(null, "Modificación de proyecto exitosa");
    } catch (SQLException e) {
 
        JOptionPane.showMessageDialog(null, "Error al modificar proyecto: " + e.toString());
    }
}
    public void EliminarProyecto(JTextField paramCodigo){
        setCodigo(Integer.parseInt(paramCodigo.getText()));
        
        CConexion objetoCOnexion = new CConexion();
        
        String consulta = "DELETE FROM proyecto WHERE proyecto.id = ?; ";
        
        try {
            CallableStatement cs = objetoCOnexion.estableceConexion().prepareCall(consulta);
            cs.setInt(1, getCodigo());
            cs.execute();
            JOptionPane.showMessageDialog(null, "Eliminacion exitosa ");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Eliminacion Fallida: " + e.toString());
        }
    }
}
